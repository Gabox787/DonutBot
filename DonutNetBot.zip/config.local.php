<?php

declare(strict_types=1);

/** Local secrets — gitignored. */
return [
    'bot_token' => '8784304720:AAFmw1ys81N40FhIfovx3jLDe3qj2W4ZJEQ',
    'admin_telegram_ids' => [],
    'db' => [
        'host' => 'localhost',
        'name' => 'itsamirc_donut',
        'user' => 'itsamirc_donut',
        'pass' => 'fASX(rM%vm1Y',
    ],
    'payment' => [
        'card_number' => '6037991122334455',
        'card_holder' => 'نام و نام خانوادگی',
        'pay_window_minutes' => 10,
    ],
    'support_username' => 'support',
    'v2ray_defaults' => [
        'server' => 'vpn.example.com',
        'port' => '443',
    ],
];

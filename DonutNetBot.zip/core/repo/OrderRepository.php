<?php

declare(strict_types=1);

final class OrderRepository
{
    public function __construct(private \PDO $pdo)
    {
    }

    public function insertPendingRow(
        \PDO $pdo,
        string $platform,
        int $userId,
        int $planId,
        int $pricePaidToman,
        string $publicId,
        string $orderKind = 'standard',
        ?int $gbOrdered = null,
    ): int {
        $st = $pdo->prepare(
            'INSERT INTO orders_config (platform, public_id, user_id, plan_id, price_paid_toman, payload, status, order_kind, gb_ordered)
             VALUES (?, ?, ?, ?, ?, NULL, \'pending\', ?, ?)'
        );
        $st->execute([$platform, $publicId, $userId, $planId, $pricePaidToman, $orderKind, $gbOrdered]);

        return (int) $pdo->lastInsertId();
    }

    /** Static test: no inventory row */
    public function insertFulfilledStaticTest(
        \PDO $pdo,
        string $platform,
        int $userId,
        int $planId,
        int $pricePaidToman,
        string $publicId,
        string $payload,
        string $testExpiresAt,
        ?string $userRemark,
    ): int {
        $st = $pdo->prepare(
            "INSERT INTO orders_config (
                platform, public_id, user_id, plan_id, price_paid_toman, payload, status,
                order_kind, plan_config_id, test_expires_at, user_remark,
                service_started_at, service_ends_at, access_status
            ) VALUES (?, ?, ?, ?, ?, ?, 'fulfilled', 'test', NULL, ?, ?, NULL, ?, 'active')"
        );
        $st->execute([$platform, $publicId, $userId, $planId, $pricePaidToman, $payload, $testExpiresAt, $userRemark, $testExpiresAt]);

        return (int) $pdo->lastInsertId();
    }

    public function markFulfilledPdo(
        \PDO $pdo,
        int $orderId,
        string $payload,
        ?int $planConfigId,
        ?string $testExpiresAt,
        ?string $userRemark,
        ?string $serviceStartedAt,
        ?string $serviceEndsAt,
        ?int $userLimitSnapshot,
        string $accessStatus = 'active',
    ): void {
        $st = $pdo->prepare(
            'UPDATE orders_config SET
                payload = ?,
                status = \'fulfilled\',
                plan_config_id = ?,
                test_expires_at = ?,
                user_remark = ?,
                service_started_at = ?,
                service_ends_at = ?,
                user_limit_snapshot = ?,
                access_status = ?
             WHERE id = ?'
        );
        $st->execute([
            $payload,
            $planConfigId,
            $testExpiresAt,
            $userRemark,
            $serviceStartedAt,
            $serviceEndsAt,
            $userLimitSnapshot,
            $accessStatus,
            $orderId,
        ]);
    }

    /** @return array<string, mixed>|null */
    public function lockNextPendingForPlanPdo(\PDO $pdo, int $planId): ?array
    {
        $st = $pdo->prepare(
            'SELECT id, platform, user_id, public_id, order_kind, price_paid_toman FROM orders_config
             WHERE plan_id = ? AND status = \'pending\' AND order_kind = \'standard\'
             ORDER BY id ASC LIMIT 1 FOR UPDATE'
        );
        $st->execute([$planId]);
        $row = $st->fetch();

        return $row ?: null;
    }

    /** @return list<array<string, mixed>> */
    public function listForUser(string $platform, int $userId, int $limit = 20): array
    {
        $lim = max(1, min(50, $limit));
        $st = $this->pdo->prepare(
            'SELECT o.id, o.public_id, o.payload, o.status, o.created_at, o.order_kind, o.gb_ordered,
                    o.test_expires_at, o.user_remark, o.access_status, o.service_started_at, o.service_ends_at,
                    o.user_limit_snapshot,
                    p.title, p.title_bale, p.description_bale, p.gb AS plan_gb, p.user_limit AS plan_user_limit, p.duration_days AS plan_duration_days
             FROM orders_config o
             JOIN plans p ON p.id = o.plan_id
             WHERE o.platform = ? AND o.user_id = ?
             ORDER BY o.id DESC
             LIMIT ' . $lim
        );
        $st->execute([$platform, $userId]);

        return $st->fetchAll() ?: [];
    }

    /** @return array<string, mixed>|null */
    public function findForUserByPublicId(string $platform, int $userId, string $publicId): ?array
    {
        $st = $this->pdo->prepare(
            'SELECT o.*, p.title, p.title_bale, p.description_bale, p.gb AS plan_gb, p.user_limit AS plan_user_limit, p.duration_days AS plan_duration_days
             FROM orders_config o
             JOIN plans p ON p.id = o.plan_id
             WHERE o.platform = ? AND o.user_id = ? AND o.public_id = ? LIMIT 1'
        );
        $st->execute([$platform, $userId, $publicId]);
        $row = $st->fetch();

        return $row ?: null;
    }

    public function setAccessStatus(int $orderId, string $status): bool
    {
        if ($status !== 'active' && $status !== 'inactive') {
            return false;
        }
        $st = $this->pdo->prepare('UPDATE orders_config SET access_status = ? WHERE id = ?');
        $st->execute([$status, $orderId]);

        return $st->rowCount() === 1;
    }

    /** @return list<array<string, mixed>> */
    public function listAllPending(int $limit = 40): array
    {
        $lim = max(1, min(100, $limit));
        $st = $this->pdo->query(
            'SELECT o.id, o.public_id, o.user_id, o.plan_id, o.price_paid_toman, o.created_at, o.platform, p.title
             FROM orders_config o
             JOIN plans p ON p.id = o.plan_id
             WHERE o.status = \'pending\'
             ORDER BY o.id ASC
             LIMIT ' . $lim
        );

        return $st->fetchAll() ?: [];
    }

    /** @return list<array<string, mixed>> */
    public function listAllRecent(int $limit = 100, int $offset = 0): array
    {
        $lim = max(1, min(500, $limit));
        $off = max(0, $offset);
        $st = $this->pdo->query(
            'SELECT o.*, p.title AS plan_title
             FROM orders_config o
             JOIN plans p ON p.id = o.plan_id
             ORDER BY o.id DESC
             LIMIT ' . $lim . ' OFFSET ' . $off
        );

        return $st->fetchAll() ?: [];
    }

    public function countAll(): int
    {
        $st = $this->pdo->query('SELECT COUNT(*) AS c FROM orders_config');
        $row = $st->fetch();

        return (int) ($row['c'] ?? 0);
    }

    /** @return array{orders_fulfilled: int, orders_pending: int, revenue_toman: int, stock_available: int} */
    public function adminStats(): array
    {
        $a = $this->pdo->query(
            'SELECT
                (SELECT COUNT(*) FROM orders_config WHERE status = \'fulfilled\') AS fulfilled,
                (SELECT COUNT(*) FROM orders_config WHERE status = \'pending\') AS pending,
                (SELECT COALESCE(SUM(price_paid_toman), 0) FROM orders_config WHERE status = \'fulfilled\') AS revenue,
                (SELECT COUNT(*) FROM plan_configs WHERE status = \'available\') AS stock'
        )->fetch();

        return [
            'orders_fulfilled' => (int) ($a['fulfilled'] ?? 0),
            'orders_pending' => (int) ($a['pending'] ?? 0),
            'revenue_toman' => (int) ($a['revenue'] ?? 0),
            'stock_available' => (int) ($a['stock'] ?? 0),
        ];
    }
}
